-- ============================================================================
--  FILE        : cpu_tb_cache.vhd
--  DESCRIPTION : L1 Cache Architecture Verification Testbench
-- ============================================================================
--  This testbench proves the functionality of the Direct-Mapped, Write-Back
--  L1 Cache by forcing Cache Misses, Cache Hits, and Dirty Evictions.
-- ============================================================================

library IEEE;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use std.textio.all;

entity cpu_tb_cache is
end cpu_tb_cache;

architecture behavior of cpu_tb_cache is

    component cpu_design_vhdl
    port (
        clk       : in    std_logic;
        reset     : in    std_logic;
        en        : out   std_logic;
        rw        : out   std_logic;
        abus      : out   std_logic_vector(15 downto 0);
        dbus      : inout std_logic_vector(15 downto 0);
        pause     : in    std_logic;
        regselect : in    std_logic_vector(1 downto 0);
        dispreg   : out   std_logic_vector(15 downto 0)
    );
    end component;

    signal clk        : std_logic := '0';
    constant clk_period : time := 10 ns;

    signal reset     : std_logic := '1';
    signal en        : std_logic;
    signal rw        : std_logic;
    signal abus      : std_logic_vector(15 downto 0);
    signal dbus      : std_logic_vector(15 downto 0);
    signal pause     : std_logic := '0';
    signal regselect : std_logic_vector(1 downto 0) := "00";
    signal dispreg   : std_logic_vector(15 downto 0);

    type memory_type is array (0 to 255) of std_logic_vector(15 downto 0);
    signal memory : memory_type := (
        
        -- ===================================================
        -- PHASE 1: POPULATE CACHE (WRITE MISSES)
        -- ===================================================
        0  => x"1007",   -- CLOAD 7
        1  => x"5010",   -- DSTORE 0x10 -> Maps to Index 0 (Dirty=1)
        2  => x"1008",   -- CLOAD 8
        3  => x"5011",   -- DSTORE 0x11 -> Maps to Index 1 (Dirty=1)
        4  => x"100F",   -- CLOAD 15
        5  => x"5012",   -- DSTORE 0x12 -> Maps to Index 2 (Dirty=1)

        -- ===================================================
        -- PHASE 2: CACHE HITS (FAST EXECUTION)
        -- ===================================================
        6  => x"2010",   -- DLOAD 0x10  -> Index 0 HIT! (Takes 1 cycle)
        7  => x"2011",   -- DLOAD 0x11  -> Index 1 HIT! (Takes 1 cycle)
        8  => x"2012",   -- DLOAD 0x12  -> Index 2 HIT! (Takes 1 cycle)

        -- ===================================================
        -- PHASE 3: THE EVICTION / WRITE-BACK
        -- ===================================================
        -- We must read new addresses that map to the same indices (0, 1, 2)
        -- to force the CPU to write our dirty answers back to Main Memory.
        
        9  => x"2018",   -- DLOAD 0x18 -> Index 0. EVICTS 0x10. (Mem[0x10] becomes 7)
        10 => x"2019",   -- DLOAD 0x19 -> Index 1. EVICTS 0x11. (Mem[0x11] becomes 8)
        11 => x"201A",   -- DLOAD 0x1A -> Index 2. EVICTS 0x12. (Mem[0x12] becomes 15)

        -- HALT
        12 => x"0000",   -- HALT
        others => x"0000"
    );

    signal dbus_out    : std_logic_vector(15 downto 0) := (others => '0');
    signal dbus_oe     : std_logic := '0';
    signal cpu_writing : std_logic;

begin

    cpu_writing <= en and (not rw);
    dbus <= dbus_out when (cpu_writing = '0' and dbus_oe = '1') else (others => 'Z');

    uut: cpu_design_vhdl
        port map(
            clk       => clk,
            reset     => reset,
            en        => en,
            rw        => rw,
            abus      => abus,
            dbus      => dbus,
            pause     => pause,
            regselect => regselect,
            dispreg   => dispreg
        );

    clk_process : process
    begin
        while true loop
            clk <= '0';
            wait for clk_period / 2;
            clk <= '1';
            wait for clk_period / 2;
        end loop;
    end process;

    stim_proc : process
    begin
        reset <= '1';
        wait for 15 ns;
        reset <= '0';
        
        -- WAIT 5000 ns to account for the new Memory Stall States!
        wait for 5000 ns;

        report "============================================================";
        report "               CACHE ARCHITECTURE VERIFICATION              ";
        report "============================================================";
        
        -- Check Index 0 Eviction
        assert memory(16) = x"0007" 
            report "FAIL: mem[0x10] should be 7. Write-back failed on Index 0!" severity error;
        if memory(16) = x"0007" then
            report "PASS: Index 0 Eviction Successful -> mem[0x10] = 7";
        end if;

        -- Check Index 1 Eviction
        assert memory(17) = x"0008" 
            report "FAIL: mem[0x11] should be 8. Write-back failed on Index 1!" severity error;
        if memory(17) = x"0008" then
            report "PASS: Index 1 Eviction Successful -> mem[0x11] = 8";
        end if;

        -- Check Index 2 Eviction
        assert memory(18) = x"000F" 
            report "FAIL: mem[0x12] should be 15. Write-back failed on Index 2!" severity error;
        if memory(18) = x"000F" then
            report "PASS: Index 2 Eviction Successful -> mem[0x12] = 15";
        end if;

        report "============================================================";
        assert false report "Simulation complete." severity failure;
    end process;

    memory_proc : process(clk)
    begin
        if rising_edge(clk) then
            if en = '1' and rw = '1' then
                dbus_out <= memory(to_integer(unsigned(abus(7 downto 0))));
                dbus_oe  <= '1';
            elsif en = '1' and rw = '0' then
                memory(to_integer(unsigned(abus(7 downto 0)))) <= dbus;
                dbus_oe <= '0';
            end if;
        end if;
    end process;

end behavior;